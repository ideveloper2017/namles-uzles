<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 23.04.2017
 * Time: 21:22
 */
function superslider(){

}
?>