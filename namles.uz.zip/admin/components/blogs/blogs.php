<?php
/**
 * Created by PhpStorm.
 * User: IDeveloper
 * Date: 20.10.2015
 * Time: 14:58
 */
echo "Blogs";
?>