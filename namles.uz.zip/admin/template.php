<?php include("header.php"); ?>
<div class="page-container">
    <?php include("mainmenu.php"); ?>
    <div class="page-container">
        <div class="page-content">
            <?php $core->getBody(); ?>
        </div>
    </div>
    <?php include("footer.php"); ?>
